import requests
import json
from pathlib import Path

# Configuration
API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
API_KEY = "AIzaSyBIwlGjycbAZNA3bLbt7RTqjRfB05qmZBQ"  # Replace with your actual API key
INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"

def read_prompts(input_file):
    """Read prompts from input file"""
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        return []

def query_gemini(api_key, prompt):
    """Send prompt to Gemini API and return response"""
    headers = {
        'Content-Type': 'application/json',
        'X-goog-api-key': api_key
    }
    
    payload = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }
    
    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"API request failed for prompt: '{prompt}'\nError: {e}")
        return None

def extract_response_text(response):
    """Extract generated text from API response"""
    if not response:
        return "Error: No response from API"
    
    try:
        if 'candidates' in response and response['candidates']:
            parts = response['candidates'][0]['content'].get('parts', [])
            return '\n'.join(part.get('text', '') for part in parts)
        return "Error: Unexpected response format"
    except Exception as e:
        return f"Error parsing response: {str(e)}"

def write_responses(output_file, prompts, responses):
    """Write prompts and responses to output file"""
    with open(output_file, 'w', encoding='utf-8') as f:
        for prompt, response in zip(prompts, responses):
            f.write(f"Prompt: {prompt}\n")
            f.write(f"Response:\n{response}\n")
            f.write("\n" + "="*80 + "\n\n")

def main():
    # Read prompts
    prompts = read_prompts(INPUT_FILE)
    if not prompts:
        return
    
    print(f"Found {len(prompts)} prompts in {INPUT_FILE}")
    
    # Process each prompt
    responses = []
    for i, prompt in enumerate(prompts, 1):
        print(f"Processing prompt {i}/{len(prompts)}: {prompt[:50]}...")
        api_response = query_gemini(API_KEY, prompt)
        response_text = extract_response_text(api_response)
        responses.append(response_text)
    
    # Write results
    write_responses(OUTPUT_FILE, prompts, responses)
    print(f"\nAll responses written to {OUTPUT_FILE}")

if __name__ == "__main__":
    # Create input file if it doesn't exist
    if not Path(INPUT_FILE).exists():
        with open(INPUT_FILE, 'w') as f:
            f.write("Explain quantum computing in simple terms\n")
            f.write("What's the meaning of life?\n")
            f.write("How does photosynthesis work?\n")
        print(f"Created sample {INPUT_FILE} with default prompts")
    
    main()
